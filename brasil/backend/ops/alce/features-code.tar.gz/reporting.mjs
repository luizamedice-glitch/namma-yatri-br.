// SPDX-License-Identifier: AGPL-3.0-or-later
import {statusCode} from './models.mjs';
const fail=(status,message)=>Object.assign(new Error(message),{status});
export const localDate=value=>new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(value));
const sqlTime=value=>value?new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(new Date(value)):null;
function integer(value,min,max,otherwise){
  if(value===undefined||value==='')return otherwise;
  if(!/^\d+$/.test(String(value))||Number(value)<min||Number(value)>max)throw fail(400,'Filtro numérico inválido');
  return Number(value);
}
function date(value){
  if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2}:\d{2})?$/.test(value))throw fail(400,'Data inválida');
  const day=value.slice(0,10);
  if(!Number.isFinite(Date.parse(day))||new Date(day).toISOString().slice(0,10)!==day)throw fail(400,'Data inválida');
  return day;
}
const shift=(day,count)=>new Date(Date.parse(day)+count*86400000).toISOString().slice(0,10);
export function reportingPeriod(body,now=Date.now()){
  const today=localDate(now),month=today.slice(0,7)+'-01';let from,to;
  switch(body.periodo??'H'){
    case 'P':from=date(body.data_inicial);to=shift(date(body.data_final),1);break;
    case 'H':from=today;to=shift(today,1);break;
    case 'M':from=month;to=shift(today,1);break;
    case 'O':to=month;from=shift(month,-1).slice(0,7)+'-01';break;
    case 'S':case 'A':{
      const weekday=(new Date(today).getUTCDay()+6)%7;from=shift(today,-weekday);
      if(body.periodo==='A'){to=from;from=shift(from,-7);}else to=shift(today,1);break;
    }
    default:throw fail(400,'Período inválido');
  }
  if(from>=to||Date.parse(to)-Date.parse(from)>366*86400000)throw fail(400,'Intervalo deve ter até um ano');
  return {from,to};
}
export function reportingService({pool,service,ids,now=Date.now}){
  return {
    async history(user,body={}){
      const driver=user.role==='driver',column=driver?'driver_id':'passenger_id';
      const page=integer(body.pagina,1,100000,1),offset=driver?0:(page-1)*20;
      let where=`r.${column}=$1 AND r.status IN ('completed','cancelled')`;const args=[user.id];
      if(driver){
        where+=" AND r.status='completed'";
        const month=integer(body.mes,1,12,undefined),year=integer(body.ano,2000,2100,undefined);
        if(month!==undefined||year!==undefined){
          if(!month||!year)throw fail(400,'Informe mês e ano');
          const start=`${year}-${String(month).padStart(2,'0')}-01`;
          const end=month===12?`${year+1}-01-01`:`${year}-${String(month+1).padStart(2,'0')}-01`;
          args.push(start,end);where+=" AND r.created_at>=($2::date::timestamp AT TIME ZONE 'America/Sao_Paulo') AND r.created_at<($3::date::timestamp AT TIME ZONE 'America/Sao_Paulo')";
        }
      }else if(['1',true,1,'true'].includes(body.apenas_finalizadas))where+=" AND r.status='completed'";
      args.push(offset);
      const rows=await pool.query(`SELECT r.id FROM rides r WHERE ${where} ORDER BY r.created_at DESC,r.id DESC LIMIT ${driver?5001:20} OFFSET $${args.length}`,args);
      if(driver&&rows.rows.length>5000)throw fail(422,'Histórico excede o limite de 5.000 corridas; selecione outro mês');
      const result=[];
      for(const row of rows.rows){
        // Reuse authoritative motor lookup/assignment and quote; no second ride model.
        const ride=await service.ride(user,row.id),id=await ids.number('ride',ride.id);
        const events=await pool.query("SELECT min(created_at) FILTER (WHERE payload->>'status'='accepted') AS accepted_at,min(created_at) FILTER (WHERE payload->>'status'='in_progress') AS started_at FROM events WHERE user_id=$1 AND kind='ride.updated' AND payload->>'rideId'=$2",[user.id,ride.id]);
        const times=events.rows[0]??{},finished=ride.status==='completed';
        const duration=finished&&times.started_at?Math.max(0,Math.floor((Date.parse(ride.updated_at)-Date.parse(times.started_at))/60000)):null;
        result.push({id:driver?String(id):id,data_hora_solicitacao:sqlTime(ride.created_at),
          inicio_corrida:sqlTime(times.started_at),final_corrida:finished?sqlTime(ride.updated_at):null,aceite:sqlTime(times.accepted_at),
          endereco_partida:ride.origin.address,endereco_destino:ride.destination.address,
          lat_partida:ride.origin.lat,lng_partida:ride.origin.lng,lat_destino:ride.destination.lat,lng_destino:ride.destination.lng,
          status_solicitacao:statusCode(ride.status),nome_passageiro:ride.passenger_name,nome_taxista:ride.driver_name,
          tipo_operacao:'P',tipo_pagamento:'D',valor_corrida:finished?ride.fare_cents/100:0,
          valor_corrida_integral:finished?ride.fare_cents/100:0,valor_desconto:0,valor_cupom:0,valor_cancelamento:0,
          valor_cashback:0,valor_carteira_creditos:0,valor_gorjeta:0,distancia_percorrida_km:null,duracao:duration,
          solicitacao_valor_detalhes:[],recibo:null,complemento_partida:'',bairro_partida:''});
      }
      return result;
    },
    async earnings(user,body={},total=false){
      if(user.role!=='driver')throw fail(403,'Somente motorista');
      const period=total?null:reportingPeriod(body,now());
      const args=[user.id];let dates='';
      if(period){args.push(period.from,period.to);dates=" AND r.updated_at>=($2::date::timestamp AT TIME ZONE 'America/Sao_Paulo') AND r.updated_at<($3::date::timestamp AT TIME ZONE 'America/Sao_Paulo')";}
      const rows=await pool.query(`SELECT to_char(r.updated_at AT TIME ZONE 'America/Sao_Paulo','YYYY-MM-DD') AS day,count(*)::int AS count,sum(q.fare_cents)::bigint AS cents FROM rides r JOIN quotes q ON q.id=r.quote_id WHERE r.driver_id=$1 AND r.status='completed'${dates} GROUP BY day ORDER BY day`,args);
      const cents=rows.rows.reduce((sum,r)=>sum+Number(r.cents),0);
      if(!Number.isSafeInteger(cents))throw fail(503,'Total fora do limite de precisão');
      if(total)return {saldo_ganhos:cents/100,aviso_creditos:'Total bruto das corridas concluídas em dinheiro; não representa saldo para saque.',endereco_destino_direcionado:null};
      return {quantidade_corridas:rows.rows.reduce((n,r)=>n+r.count,0),saldo_ganhos_periodo:cents/100,
        resumo:rows.rows.map(r=>({data:r.day,valor:Number(r.cents)/100}))};
    }
  };
}
