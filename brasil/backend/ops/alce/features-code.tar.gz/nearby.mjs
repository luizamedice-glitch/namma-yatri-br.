// SPDX-License-Identifier: AGPL-3.0-or-later
// Read the same drivers table, freshness and 5 km eligibility as Namma dispatch.
// This does not update availability, GPS, rides, sessions or vendor services.
const fail=(status,message)=>Object.assign(new Error(message),{status});
export function nearbyDrivers({pool,ids,allowedIds}) {
  const allowed=[...allowedIds];
  return async (user,{lat,lng,bandeira_configuracao_id:central})=>{
    if(user.role!=='passenger')throw fail(403,'Perfil sem permissão');
    if(central!==undefined&&central!==null&&String(central)!=='1')throw fail(422,'Central fora do laboratório');
    const result=await pool.query(`SELECT d.user_id,d.lat,d.lng FROM drivers d
      JOIN users u ON u.id=d.user_id
      WHERE d.user_id=ANY($3::uuid[]) AND u.role='driver' AND d.available=true
      AND d.location_at>now()-interval '60 seconds' AND d.location_at<=now()
      AND d.lat BETWEEN -90 AND 90 AND d.lng BETWEEN -180 AND 180
      AND NOT EXISTS (SELECT 1 FROM rides r WHERE r.driver_id=d.user_id
        AND r.status IN ('accepted','arrived','in_progress'))
      AND 6371000*2*asin(sqrt(least(1.0,
        power(sin(radians(d.lat-$1::float8)/2),2)+
        cos(radians(d.lat))*cos(radians($1::float8))*
        power(sin(radians(d.lng-$2::float8)/2),2))))<=5000
      ORDER BY d.user_id LIMIT 50`,[lat,lng,allowed]);
    return Promise.all(result.rows.map(async d=>({
      id:await ids.number('user',d.user_id),status_taxi:'L',lat:d.lat,lng:d.lng
    })));
  };
}
