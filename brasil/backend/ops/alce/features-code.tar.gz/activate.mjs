// SPDX-License-Identifier: AGPL-3.0-or-later
// Run manually by the owner over SSH. Never call from CI or HTTP routes.
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const env=process.env;
if(env.ALCE_ISOLATED_MODE!=='true'||env.NODE_ENV!=='development'||
    new URL(env.DATABASE_URL).pathname!=='/alce_lab'||Date.now()>=Date.parse(env.YATRI_DRIVER_PILOT_UNTIL))
  throw Error('Laboratório isolado indisponível ou fora do prazo');
const root=env.NAMMA_BACKEND_ROOT||'/app';
const {connectDatabase}=await import(pathToFileURL(resolve(root,'src/db.mjs')).href);
const {issuePairing}=await import(pathToFileURL(resolve(root,'src/driver-pairing.mjs')).href);
const pool=await connectDatabase(env.DATABASE_URL);
try {
  for(const [role,label]of [['driver','MOTORISTA'],['passenger','PASSAGEIRO']]){
    const activation=await issuePairing(pool,role);
    console.log(label+': '+activation.code);
  }
  console.log('Cada código vale por 24 horas e pode ser utilizado uma vez. Não compartilhe.');
} finally {await pool.end();}
