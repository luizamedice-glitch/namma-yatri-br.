// SPDX-License-Identifier: AGPL-3.0-or-later
// Operator CLI inside the isolated Alce container; no public management endpoint.
import {readFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import {bannerService} from './banners.mjs';
if(process.env.ALCE_ISOLATED_MODE!=='true'||new URL(process.env.DATABASE_URL).pathname!=='/alce_lab')throw Error('ISOLATED_ALCE_REQUIRED');
const {connectDatabase}=await import(pathToFileURL((process.env.NAMMA_BACKEND_ROOT||'/app')+'/src/db.mjs'));
const pool=await connectDatabase(process.env.DATABASE_URL);
try{const banners=bannerService({pool});await banners.initialize();const input=JSON.parse(await readFile(process.argv[2]||'/dev/stdin','utf8'));await banners.save(input);console.log(JSON.stringify({campaignUpdated:true,slug:input.slug}));}finally{await pool.end();}
