// SPDX-License-Identifier: AGPL-3.0-or-later
const fail=(status,message)=>Object.assign(new Error(message),{status});
export function campaignInput(value){
 if(!value||typeof value!=='object'||!/^[a-z0-9-]{3,60}$/.test(value.slug||''))throw fail(400,'Identificador de campanha inválido');
 let url;try{url=new URL(value.url);}catch{throw fail(400,'Link inválido');}
 if(url.protocol!=='https:'||url.username||url.password)throw fail(400,'Use um link HTTPS');
 const data=Buffer.from(value.imageBase64||'','base64');
 if(!data.length||data.length>1024*1024||data.subarray(0,8).toString('hex')!=='89504e470d0a1a0a')throw fail(400,'Use uma imagem PNG de até 1 MB');
 const starts=value.startsAt?new Date(value.startsAt):new Date('2026-01-01');
 const ends=value.endsAt?new Date(value.endsAt):null;
 if(!Number.isFinite(+starts)||ends&&(!Number.isFinite(+ends)||ends<=starts))throw fail(400,'Período inválido');
 const cities=value.cities??[1];if(!Array.isArray(cities)||!cities.length||cities.some(x=>!Number.isInteger(x)||x<1||x>2147483647))throw fail(400,'Cidades inválidas');
 return {slug:value.slug,url:url.href,data,starts,ends,cities,enabled:value.enabled!==false,order:Number.isInteger(value.order)?value.order:0};
}
export function bannerService({pool,origin='https://52-67-246-31.sslip.io'}){
 return {
  async initialize(){await pool.query(`CREATE TABLE IF NOT EXISTS alce_campaigns (
   id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,slug text UNIQUE NOT NULL,
   target_url text NOT NULL,image_data bytea NOT NULL CHECK(octet_length(image_data)<=1048576),
   cities integer[] NOT NULL DEFAULT ARRAY[1],enabled boolean NOT NULL DEFAULT true,
   starts_at timestamptz NOT NULL,ends_at timestamptz,sort_order integer NOT NULL DEFAULT 0,
   clicks bigint NOT NULL DEFAULT 0,views bigint NOT NULL DEFAULT 0)`);},
  async save(input,{insertOnly=false}={}){
   const v=campaignInput(input);
   return pool.query(`INSERT INTO alce_campaigns(slug,target_url,image_data,cities,enabled,starts_at,ends_at,sort_order) VALUES($1,$2,$3,$4,$5,$6,$7,$8)
    ON CONFLICT(slug) ${insertOnly?'DO NOTHING':'DO UPDATE SET target_url=excluded.target_url,image_data=excluded.image_data,cities=excluded.cities,enabled=excluded.enabled,starts_at=excluded.starts_at,ends_at=excluded.ends_at,sort_order=excluded.sort_order'}`,[v.slug,v.url,v.data,v.cities,v.enabled,v.starts,v.ends,v.order]);
  },
  async list(city=1){
   if(!Number.isInteger(Number(city))||Number(city)!==1)throw fail(400,'Cidade fora desta operação');
   const r=await pool.query('SELECT id,target_url FROM alce_campaigns WHERE enabled AND $1=ANY(cities) AND starts_at<=now() AND (ends_at IS NULL OR ends_at>now()) ORDER BY sort_order,id LIMIT 20',[Number(city)]);
   return r.rows.map(v=>({id:v.id,url:v.target_url,url_foto:origin+'/api/passageiro/bannerImagem?id='+v.id}));
  },
  async image(id){
   if(!/^[1-9]\d{0,9}$/.test(String(id)))throw fail(400,'Banner inválido');
   const r=await pool.query('SELECT image_data FROM alce_campaigns WHERE id=$1 AND enabled AND starts_at<=now() AND (ends_at IS NULL OR ends_at>now())',[id]);
   if(!r.rowCount)throw fail(404,'Banner indisponível');return r.rows[0].image_data;
  },
  async interaction(id,clicked){
   if(!/^[1-9]\d{0,9}$/.test(String(id)))throw fail(400,'Banner inválido');
   await pool.query(`UPDATE alce_campaigns SET ${clicked?'clicks=clicks+1':'views=views+1'} WHERE id=$1 AND enabled`,[id]);return {};
  }
 };
}
