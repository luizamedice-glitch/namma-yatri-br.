// SPDX-License-Identifier: AGPL-3.0-or-later
export function legacyIds(pool) {
  const kinds = new Set(['user', 'ride', 'quote']);
  const checkKind = k => { if (!kinds.has(k)) throw Error('INVALID_ENTITY_KIND'); };
  return {
    async initialize() {
      await pool.query(`CREATE TABLE IF NOT EXISTS alce_legacy_ids (
        id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
        kind text NOT NULL CHECK(kind IN ('user','ride','quote')),
        entity_id uuid NOT NULL, UNIQUE(kind,entity_id))`);
    },
    async number(kind, uuid) {
      checkKind(kind);
      // Polling must not UPDATE existing mappings or consume an identity sequence
      // value on every read. The upsert still resolves concurrent first creation.
      const existing=await pool.query('SELECT id FROM alce_legacy_ids WHERE kind=$1 AND entity_id=$2',[kind,uuid]);
      if(existing.rowCount)return existing.rows[0].id;
      const r = await pool.query(`INSERT INTO alce_legacy_ids(kind,entity_id) VALUES($1,$2)
        ON CONFLICT(kind,entity_id) DO UPDATE SET entity_id=excluded.entity_id RETURNING id`, [kind, uuid]);
      return r.rows[0].id;
    },
    async uuid(kind, number) {
      checkKind(kind);
      if (!/^[1-9][0-9]{0,9}$/.test(String(number)) || Number(number)>2147483647) throw Object.assign(Error('Identificador inválido'),{status:400});
      const r = await pool.query('SELECT entity_id FROM alce_legacy_ids WHERE kind=$1 AND id=$2',[kind,number]);
      if (!r.rowCount) throw Object.assign(Error('Identificador não encontrado'),{status:404});
      return r.rows[0].entity_id;
    },
  };
}
