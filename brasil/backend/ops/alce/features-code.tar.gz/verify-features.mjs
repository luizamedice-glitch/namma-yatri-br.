// SPDX-License-Identifier: AGPL-3.0-or-later
// Read-only deployment checks: no messages, trips, availability or GPS changes.
import assert from 'node:assert/strict';
import {randomBytes,createHash} from 'node:crypto';
import {passengerPilotId} from '/app/src/driver-pilot.mjs';
import {pathToFileURL} from 'node:url';
assert.equal(process.env.ALCE_ISOLATED_MODE,'true');assert.equal(new URL(process.env.DATABASE_URL).pathname,'/alce_lab');
const {connectDatabase}=await import(pathToFileURL('/app/src/db.mjs'));
const pool=await connectDatabase(process.env.DATABASE_URL);
try{
 const base='https://52-67-246-31.sslip.io';
 const r=await fetch(base+'/api/configuracao/passageiro');assert.equal(r.status,200);const config=(await r.json()).response;assert.ok(config.anuncios.length>=1);
 const image=await fetch(config.anuncios[0].url_foto);assert.equal(image.status,200);assert.equal(image.headers.get('content-type'),'image/png');const bytes=Buffer.from(await image.arrayBuffer());assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
 for(const prefix of ['', '/api']){
  const denied=await fetch(base+prefix+'/mensagem/conversaSolicitacao',{method:'POST',headers:{'content-type':'application/json'},body:'{"solicitacao_id":1}'});assert.equal(denied.status,401);
 }
 const tables=await pool.query("SELECT to_regclass('alce_chat_messages') IS NOT NULL AS chat,to_regclass('alce_campaigns') IS NOT NULL AS campaigns");assert.equal(tables.rows[0].chat,true);assert.equal(tables.rows[0].campaigns,true);
 const auth=randomBytes(32).toString('hex'),hash=createHash('sha256').update(auth).digest('hex');
 try{
  await pool.query('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES($1,$2,now()+make_interval(secs=>60))',[hash,passengerPilotId]);
  for(const path of ['/api/endereco/lista','/api/alce/addresses/history']){
   const r=await fetch(base+path,{headers:{'x-session-token':auth}});assert.equal(r.status,200);const b=await r.json();assert.ok(Array.isArray(b.response));if(path.endsWith('/history'))assert.ok(b.response.length<=3);
  }
 }finally{await pool.query('DELETE FROM sessions WHERE token_hash=$1',[hash]);}
 console.log(JSON.stringify({addressFavoritesHttps:true,addressHistoryHttps:true,featuresHttps:true,campaignImage:true,chatSessionRequired:true,chatPersistence:true,rideGpsAndUserSessionsMutated:false}));
}finally{await pool.end();}
