// SPDX-License-Identifier: AGPL-3.0-or-later
// Read-only deployment checks: no messages, trips, availability or GPS changes.
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
assert.equal(process.env.ALCE_ISOLATED_MODE,'true');assert.equal(new URL(process.env.DATABASE_URL).pathname,'/alce_lab');
const {connectDatabase}=await import(pathToFileURL('/app/src/db.mjs'));
const pool=await connectDatabase(process.env.DATABASE_URL);
try{
 const base='https://52-67-246-31.sslip.io';
 const r=await fetch(base+'/api/configuracao/passageiro');assert.equal(r.status,200);const config=(await r.json()).response;assert.ok(config.anuncios.length>=1);
 const image=await fetch(config.anuncios[0].url_foto);assert.equal(image.status,200);assert.equal(image.headers.get('content-type'),'image/png');const bytes=Buffer.from(await image.arrayBuffer());assert.equal(bytes.subarray(0,8).toString('hex'),'89504e470d0a1a0a');
 for(const prefix of ['', '/api']){
  const denied=await fetch(base+prefix+'/mensagem/conversaSolicitacao',{method:'POST',headers:{'content-type':'application/json'},body:'{"solicitacao_id":1}'});assert.equal(denied.status,401);
 }
 const tables=await pool.query("SELECT to_regclass('alce_chat_messages') IS NOT NULL AS chat,to_regclass('alce_campaigns') IS NOT NULL AS campaigns");assert.equal(tables.rows[0].chat,true);assert.equal(tables.rows[0].campaigns,true);
 console.log(JSON.stringify({featuresHttps:true,campaignImage:true,chatSessionRequired:true,chatPersistence:true,rideGpsAndUserSessionsMutated:false}));
}finally{await pool.end();}
