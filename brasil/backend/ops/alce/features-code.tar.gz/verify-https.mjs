// SPDX-License-Identifier: AGPL-3.0-or-later
// Operator-only acceptance against the isolated lab. No credentials are printed.
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
const load=name=>import(pathToFileURL(resolve(process.env.NAMMA_BACKEND_ROOT||'/app','src',name+'.mjs')).href);
const {connectDatabase}=await load('db');
const {issuePairing,pairingHash}=await load('driver-pairing');
const {mobilityService}=await load('mobility');
const {driverPilotId,passengerPilotId}=await load('driver-pilot');
assert.equal(process.env.ALCE_ISOLATED_MODE,'true');
assert.equal(new URL(process.env.DATABASE_URL).pathname,'/alce_lab');
const pool=await connectDatabase(process.env.DATABASE_URL);
const service=mobilityService(pool,{}, {allowDevelopmentAccounts:true});
const base='https://52-67-246-31.sslip.io';
const tokens=[],pairs=[];let driver,passenger,rideUuid,locationWritten=false;
async function call(path,body={},token,expected=200,method='POST'){
  const url=new URL(base+path);
  if(method==='GET')for(const [k,v]of Object.entries(body))url.searchParams.set(k,v);
  const response=await fetch(url,{method,signal:AbortSignal.timeout(20000),
    headers:{'content-type':'application/json',...(token?{'Temporary-Access-Token':token}:{})},
    ...(method==='GET'?{}:{body:JSON.stringify(body)})});
  assert.equal(response.status,expected,method+' '+path+' unexpected HTTP status');
  const envelope=await response.json();assert.equal(envelope.success,expected<400);
  return envelope.response;
}
// While a phone is online or a real request is open, do not move its GPS,
// availability or rides to execute a synthetic acceptance cycle.
const live=await pool.query("SELECT (SELECT available FROM drivers WHERE user_id=$1) AS online,EXISTS(SELECT 1 FROM rides WHERE status IN ('searching','accepted','arrived','in_progress')) AS active",[driverPilotId]);
// Deployment acceptance is read-only by default, even with idle phones. The
// destructive synthetic cycle is an explicit operator opt-in, never automatic.
if(process.env.ALCE_ACCEPTANCE_ALLOW_MUTATION!=='true'||live.rows[0].online||live.rows[0].active) {
  try {
    await call('/taxi/status',{status:'L'},undefined,401);
    await call('/solicitacao20/listaDisponiveis',{},undefined,401,'GET');
    const config=await call('/configuracao',{},undefined,200,'GET');assert.equal(config.tp_status_l,5);
    const {driverOfferModel}=await import('./models.mjs');
    const latest=await pool.query("SELECT e.id,e.created_at,r.id AS ride_id FROM events e JOIN rides r ON e.payload->>'rideId'=r.id::text WHERE e.user_id=$1 AND e.kind='offer.created' AND r.driver_id=$1 AND r.status='completed' ORDER BY e.id DESC LIMIT 1",[driverPilotId]);
    assert.equal(latest.rowCount,1,'Persisted completed pilot ride required for nondisruptive serialization acceptance');
    const d={id:driverPilotId,role:'driver'};
    const ride=await service.ride(d,latest.rows[0].ride_id);
    const ids={number:async(kind,id)=>{
      const rows=await pool.query('SELECT id FROM alce_legacy_ids WHERE kind=$1 AND entity_id=$2',[kind,id]);
      assert.equal(rows.rowCount,1,'Existing legacy identity required');return rows.rows[0].id;
    }};
    const model=await driverOfferModel(ride,ids,latest.rows[0],await ids.number('user',driverPilotId));
    assert.equal(model.eventoSolicitacaos[0].id,String(latest.rows[0].id));
    assert.match(model.eventoSolicitacaos[0].data_hora,/^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$/);
    assert.ok(model.eventoSolicitacaos[0].taxistaEventoSolicitacaos.length);
    assert.equal(model.valor_ganho,ride.fare_cents/100);
    const snapshot=await service.snapshot(d);
    const activeRide=snapshot.rides[0];
    const probeRide=activeRide??ride;
    let postAcceptReadVerified=false,pickupEtaVerified=false,passengerRegistrationVerified=false;
    if(probeRide){
      try {
        const probe={};
        for(const role of ['driver','passenger']){
          const pair=await issuePairing(pool,role);pairs.push(pair);
          const session=await call('/lab/pair/'+role,{code:pair.code});
          tokens.push(session.token);probe[role]=session.token;
        }
        const numericId=await ids.number('ride',probeRide.id);
        await call('/taxi/proximos',{lat:0,lng:0},undefined,401,'GET');
        await call('/taxi/proximos',{lat:0,lng:0},probe.driver,403,'GET');
        const nearby=await call('/api/taxi/proximos',{lat:0,lng:0,bandeira_configuracao_id:1},probe.passenger,200,'GET');
        assert.ok(Array.isArray(nearby));
        for(const d of nearby){assert.ok(Number.isInteger(d.id));assert.equal(d.status_taxi,'L');assert.ok(Number.isFinite(d.lat)&&Number.isFinite(d.lng));}
        const known=(await pool.query('SELECT lat,lng FROM drivers WHERE user_id=$1',[driverPilotId])).rows[0];
        if(Number.isFinite(known?.lat)&&Number.isFinite(known?.lng)){
          const nearKnown=await call('/taxi/proximos',{lat:known.lat,lng:known.lng,bandeira_configuracao_id:1},probe.passenger,200,'GET');
          assert.ok(Array.isArray(nearKnown));assert.ok(nearKnown.length<=1);
          for(const marker of nearKnown){
            assert.equal(marker.id,await ids.number('user',driverPilotId));
            assert.equal(marker.status_taxi,'L');assert.ok(Number.isFinite(marker.lat)&&Number.isFinite(marker.lng));
          }
        }
        const passengerConfig=await call('/configuracao/passageiro',{},undefined,200,'GET');
        assert.equal(passengerConfig.tipo_marcador_utilizado,'2');
        const detail=await call('/solicitacao20/detalhes',{id:numericId},probe.driver,200,'GET');
        assert.ok(detail.bandeira_chamada);assert.ok(detail.registroCorrida);
        for(const key of ['qtd_paradas_adicionais','trajeto_alterado','duracao_aceite','duracao_em_andamento'])
          assert.ok(Number.isInteger(detail[key]));
        const profile=await call('/solicitacao/detalhesTaxista',{id:numericId},probe.passenger,200,'GET');
        assert.ok(profile.taxista.nome);assert.ok(profile.taxista.veiculo.placa);
        const restore=await call('/solicitacao30/ativa',{},probe.driver,200,'GET');
        if(activeRide)assert.ok(restore.solicitacoes.some(r=>r.id===numericId&&r.bandeira_chamada));
        else assert.equal(restore.solicitacoes.length,0);
        const poll=await fetch(base+'/solicitacao20/index?id='+numericId,{headers:{'X-Session-Token':probe.passenger},signal:AbortSignal.timeout(20000)});
        const polled=await poll.json();
        if(poll.status===200){
          const passengerState=polled.response;
          assert.equal(passengerState.id,numericId);assert.equal(passengerState.tipo_condutor,'T');
          assert.ok(['A','E','F','C'].includes(passengerState.statusSolicitacao.status));
          if(passengerState.registroCorrida){
            assert.equal(typeof passengerState.registroCorrida.nome,'string');
            assert.ok(passengerState.registroCorrida.nome.length);
            assert.ok(['C','E'].includes(passengerState.registroCorrida.registro));
            passengerRegistrationVerified=true;
          }
          if(passengerState.status==='A'){
            assert.ok(Number.isInteger(passengerState.estimativa_segundos_passageiro));pickupEtaVerified=true;
          }
        }else{
          assert.equal(poll.status,409);
          assert.ok(polled.errors?.some(message=>String(message).includes('Localização do motorista desatualizada')));
        }
        const cancellable=['searching','accepted','arrived'].includes(probeRide.status);
        const reasons=await call('/motivoCancelamento/cliente20',{solicitacao_id:numericId},probe.passenger,cancellable?200:409,'GET');
        if(cancellable){assert.equal(reasons.taxa_cancelamento,0);assert.ok(reasons.motivos.length);}
        await call('/motivoCancelamento/taxista',{solicitacao_id:numericId},probe.passenger,403,'GET');
        // The native spelling must reach authorization even without a session.
        await call('/solicitacao20/recalculoRota',{solicitacao_id:numericId},undefined,401,'GET');
        // Completed rides return their persisted trip route without moving GPS
        // or requesting a new quote/ride/Google route during deployment.
        if(probeRide.status==='completed'){
          const route=await call('/solicitacao20/recalculoRota',{solicitacao_id:numericId},probe.passenger,200,'GET');
          assert.ok(route.rota_polyline===probeRide.route.encodedPolyline,'Persisted route mismatch');
        }
        const history=await call('/solicitacao/historico',{pagina:1},probe.passenger,200,'GET');
        assert.ok(Array.isArray(history));
        const earnings=await call('/taxista/obterGanhos',{},probe.driver);
        assert.ok(Number.isFinite(earnings.saldo_ganhos));
        const daily=await call('/taxista/resumoGanhos',{periodo:'H'},probe.driver,200,'GET');
        assert.ok(Number.isInteger(daily.quantidade_corridas));
        postAcceptReadVerified=true;
      } finally {
        for(const token of tokens)await service.logout(token);
        for(const pair of pairs)await pool.query('DELETE FROM sessions WHERE token_hash=$1',[pairingHash(pair.code,pair.role)]);
      }
    }
    console.log(JSON.stringify({httpsAuthGuard:true,driverOfferContractWithPersistedData:true,
      liveDriverAndRidesPreserved:true,rideStateReadOnly:true,nativeOperationsReadVerified:true,historyAndEarningsReadVerified:true,postAcceptReadVerified,pickupEtaVerified,passengerRegistrationVerified,probeSessionsRevoked:true,liveOfferCount:snapshot.offers.length,
      nearbyReadOnlyVerified:true,androidDeviceTest:false}));
  } finally {await pool.end();}
} else try {
  const active=await pool.query("SELECT 1 FROM rides WHERE status IN ('searching','accepted','arrived','in_progress') LIMIT 1");
  assert.equal(active.rowCount,0,'Refusing acceptance while a lab ride is active');
  await call('/taxi/status',{status:'L'},undefined,401);
  const config=await call('/configuracao',{},undefined,200,'GET');assert.equal(config.tp_status_l,5);
  assert.equal((await call('//configuracao',{},undefined,200,'GET')).tp_status_l,5);
  assert.equal((await call('//passageiro/verificarLogin')).proxima_etapa,'S');
  assert.ok(config.chave_google_api);assert.equal(config.tempo_polling,600000);
  for(const role of ['driver','passenger']){
    const pair=await issuePairing(pool,role);pairs.push(pair);
    const model=await call(role==='driver'?'/taxista/login':'/passageiro/login20',{senha:pair.code});
    const token=role==='driver'?model.api_token:model.temporary_access_token;tokens.push(token);
    assert.ok(Date.parse(model.expires_at)>Date.now());
    const identity=await service.authenticate(token);
    if(role==='driver')driver={...identity,token,legacyId:model.id};else passenger={...identity,token,legacyId:model.id};
    await call(role==='driver'?'/taxista/login':'/passageiro/login20',{senha:pair.code},undefined,401);
  }
  assert.equal(driver.id,driverPilotId);assert.equal(passenger.id,passengerPilotId);
  // Explicit synthetic coordinates for server acceptance, never described as phone GPS.
  await call('/taxi/posicao',{lat:-23.55052,lng:-46.633308},driver.token,200,'GET');locationWritten=true;
  await call('/taxi/status',{status:'L'},driver.token);
  const reverse=await call('/geo//maps/api/geocode/json',{latlng:'-23.55052,-46.633308'},passenger.token,200,'GET');
  assert.ok(reverse.results[0].formatted_address);assert.ok(reverse.results[0].address_components.some(c=>c.types.includes('route')));
  const raw=await fetch(base+'/geo//maps/api/geocode/json?latlng=-23.55052,-46.633308',{headers:{'X-Session-Token':passenger.token}});
  assert.equal(raw.status,200);const rawGeo=await raw.json();assert.equal(rawGeo.status,'OK');assert.ok(rawGeo.results.length);
  const places=await call('/places//maps/api/place/autocomplete/json',{input:'Avenida Paulista São Paulo',location:'-23.55052,-46.633308'},passenger.token,200,'GET');
  assert.ok(places.predictions.length>0);
  const selected=await call('/geo/maps/api/geocode/json',{placeid:places.predictions[0].place_id},passenger.token,200,'GET');
  assert.ok(Number.isFinite(selected.results[0].geometry.location.lat));
  assert.ok(selected.results[0].address_components.length);
  const quote=await call('/solicitacao20/estimativasCorrida',{lat_partida:-23.55052,lng_partida:-46.633308,
    lat_desejado:-23.561414,lng_desejado:-46.655881,endereco_partida:'Aceite técnico: Praça da Sé',endereco_desejado:'Aceite técnico: MASP'},passenger.token);
  assert.ok(quote.estimativa_km>0);assert.ok(quote.rota_polyline);
  const cashEstimates=quote.categorias[0].estimativa_pagamentos.D;
  assert.ok(Array.isArray(cashEstimates)&&cashEstimates.length===1);
  assert.ok(Number.isFinite(cashEstimates[0].valor_estimativa)&&cashEstimates[0].valor_estimativa>0);
  assert.equal(cashEstimates[0].valor_estimativa,quote.categorias[0].estimativa_original);
  const request=await call('/solicitacao20/nova',{solicitacao:{estimativa_id:quote.estimativa_id}},passenger.token);
  const found=await pool.query("SELECT entity_id FROM alce_legacy_ids WHERE kind='ride' AND id=$1",[request.id]);
  rideUuid=found.rows[0].entity_id;
  const offers=await call('/solicitacao20/listaDisponiveis',{},driver.token,200,'GET');
  assert.ok(offers.disponiveis.some(o=>o.id===request.id));
  assert.equal((await call('/solicitacao/aceitar',{id:request.id},driver.token)).status_aceite,'V');
  await call('/solicitacao/registroCorrida',{id:request.id,registro:'C'},driver.token);
  const arrived=await call('/solicitacao20/index',{id:request.id},passenger.token,200,'GET');
  assert.equal(arrived.statusSolicitacao.status,'A');assert.equal(arrived.registroCorrida.registro,'C');
  assert.equal(typeof arrived.registroCorrida.nome,'string');assert.ok(arrived.registroCorrida.nome.length);
  assert.ok(Number.isInteger(arrived.estimativa_segundos_passageiro));
  await call('/solicitacao/registroCorrida',{id:request.id,registro:'E'},driver.token);
  const started=await call('/solicitacao20/ativa',{},passenger.token,200,'GET');
  assert.equal(started.statusSolicitacao.status,'E');assert.equal(started.registroCorrida.registro,'E');
  assert.equal(typeof started.registroCorrida.nome,'string');assert.ok(started.registroCorrida.nome.length);
  assert.equal((await call('/solicitacao/finalizar',{id:request.id},driver.token)).status,'F');
  assert.equal((await call('/solicitacao20/index',{id:request.id},passenger.token,200,'GET')).status,'F');
  assert.equal(await call('/solicitacao20/ativa',{},passenger.token,200,'GET'),null);
  const persisted=await pool.query('SELECT status FROM rides WHERE id=$1',[rideUuid]);assert.equal(persisted.rows[0].status,'completed');
  await call('/lab/logout',{},driver.token);await call('/taxi/status',{status:'O'},driver.token,401);
  console.log(JSON.stringify({httpsLegacyCycle:true,realGooglePlacesAndRoute:true,persistedCompletion:true,
    sessionsSingleUseAndRevoked:true,syntheticCoordinates:true,androidDeviceTest:false}));
} finally {
  if(rideUuid&&passenger){
    const ride=await service.ride(passenger,rideUuid);
    if(ride.status==='in_progress')await service.change(driver,rideUuid,'complete');
    else if(['searching','accepted','arrived'].includes(ride.status))await service.change(passenger,rideUuid,'cancel');
  }
  if(driver)await service.availability(driver,{available:false});
  if(locationWritten)await pool.query('UPDATE drivers SET lat=NULL,lng=NULL,location_at=NULL WHERE user_id=$1',[driverPilotId]);
  for(const token of tokens)await service.logout(token);
  for(const pair of pairs)await pool.query('DELETE FROM sessions WHERE token_hash=$1',[pairingHash(pair.code,pair.role)]);
  await pool.end();
}
