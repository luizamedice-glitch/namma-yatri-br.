// SPDX-License-Identifier: AGPL-3.0-or-later
// Durable acknowledgement of the native driver's finalization queue. Reuses
// engine transitions, transactions and the existing private events table.
const fail=(status,message)=>Object.assign(new Error(message),{status});
export function receiptStore({pool,service,transaction}){
  return async(user,id,details={})=>{
    if(user.role!=='driver')throw fail(403,'Somente o motorista atribuído');
    // Only measured client telemetry is accepted here. Prices, discounts,
    // ratings, blocking and payment claims are never applied from this payload.
    const telemetry={};
    for(const key of ['trajeto_corrida','trajeto_passageiro'])if(details[key]!=null){
      if(typeof details[key]!=='string'||details[key].length>16000)throw fail(400,'Trajeto inválido');
      telemetry[key]=details[key];
    }
    for(const key of ['lat_destino','lng_destino','duracao_taximetro_virtual','duracao_passageiro_taximetro_virtual',
      'distancia_taximetro_virtual','distancia_passageiro_taximetro_virtual','tempo_parado_taximetro_virtual'])if(details[key]!=null){
      const value=details[key];
      if(typeof value!=='number'||!Number.isFinite(value)||Math.abs(value)>Number.MAX_SAFE_INTEGER||
        (key==='lat_destino'?Math.abs(value)>90:key==='lng_destino'?Math.abs(value)>180:value<0))throw fail(400,'Telemetria inválida');
      telemetry[key]=value;
    }
    const ride=await service.ride(user,id);
    if(ride.driver_id!==user.id)throw fail(403,'Somente o motorista atribuído');
    // Never invent missing arrival/start events while replaying an offline queue.
    if(!['in_progress','completed'].includes(ride.status))throw fail(409,'Corrida ainda não pode ser finalizada');
    await service.change(user,id,'complete');
    // If persistence fails after completion, HTTP remains an error. The phone
    // retains its queue; retry confirms the transition and persists the receipt.
    return transaction(pool,async db=>{
      const previous=await db.query("SELECT id FROM events WHERE user_id=$1 AND kind='alce.receipt' AND payload->>'rideId'=$2 LIMIT 1",[user.id,id]);
      if(previous.rowCount)return {recorded:true,replayed:true};
      await db.query('INSERT INTO events(user_id,kind,payload) VALUES($1,$2,$3)',
        [user.id,'alce.receipt',{rideId:id,fareCents:ride.fare_cents,clientTelemetry:telemetry}]);
      return {recorded:true,replayed:false};
    });
  };
}
