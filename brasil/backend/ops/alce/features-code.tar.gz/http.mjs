// SPDX-License-Identifier: AGPL-3.0-or-later
import http from 'node:http';
import {configuration,loginModel,estimateModel,rideModel,driverRideModel,driverOfferModel,statusObject,statusCode} from './models.mjs';
import {nearbyDrivers} from './nearby.mjs';
const fail=(status,message)=>Object.assign(new Error(message),{status});
const requireRole=(u,r)=>{if(u.role!==r)throw fail(403,'Perfil sem permissão');};
function object(value) {
  if(typeof value==='string'){try{value=JSON.parse(value);}catch{throw fail(400,'Objeto JSON inválido');}}
  if(!value || typeof value!=='object' || Array.isArray(value))throw fail(400,'Objeto inválido');
  return value;
}
// Original clients use id, solicitacao_id, and (for finalization) solicitacao.id.
// Reject conflicting references rather than acting on an arbitrary precedence.
function rideReference(body,details) {
  const values=[body.id,body.solicitacao_id,details?.id].filter(v=>v!==undefined&&v!==null);
  if(new Set(values.map(String)).size>1)throw fail(400,'Identificadores de corrida divergentes');
  return values[0];
}
function number(value,max) {
  if((typeof value!=='number' && typeof value!=='string') || String(value).trim()==='')throw fail(400,'Coordenada inválida');
  const n=Number(value);if(!Number.isFinite(n)||Math.abs(n)>max)throw fail(400,'Coordenada inválida');return n;
}
function points(body) {
  return {origin:{lat:number(body.lat_partida,90),lng:number(body.lng_partida,180),address:body.endereco_partida||'Origem selecionada'},
    destination:{lat:number(body.lat_desejado,90),lng:number(body.lng_desejado,180),address:body.endereco_desejado||'Destino selecionado'}};
}
async function read(req,url,maxBytes=20000) {
  if(req.method==='GET')return Object.fromEntries(url.searchParams);
  const chunks=[];let size=0;
  for await(const c of req){size+=c.length;if(size>maxBytes)throw fail(413,'Corpo excede o limite desta operação');chunks.push(c);}
  const bytes=Buffer.concat(chunks),type=req.headers['content-type']||'';
  if(!bytes.length)return {};
  if(type.includes('multipart/form-data')){
    let form;
    try {form=await new Request('http://localhost',{method:'POST',headers:{'content-type':type},body:bytes}).formData();}
    catch {throw fail(400,'Formulário multipart inválido');}
    const body={};for(const [k,v] of form){if(typeof v!=='string')throw fail(415,'Arquivos não suportados nesta operação');body[k]=v;}return body;
  }
  if(type.includes('application/x-www-form-urlencoded'))return Object.fromEntries(new URLSearchParams(bytes.toString()));
  try{return object(JSON.parse(bytes.toString()));}catch{throw fail(400,'JSON inválido');}
}

export function createLegacyApi({pool,service,ids,pairing,until,allowedIds,maps={},saveReceipt,reporting,androidMapsKey='',chat,banners,addresses,now=Date.now,audit=()=>{}}) {
  const expiration=Date.parse(until),identities=new Set(allowedIds);
  if(!Number.isFinite(expiration)||expiration<=now()||identities.size!==2)throw Error('ISOLATED_PILOT_CONFIGURATION_REQUIRED');
  const buckets=new Map();
  const nearby=nearbyDrivers({pool,ids,allowedIds});
  async function ownUser(token) {
    const user=await service.authenticate(token);
    if(!identities.has(user.id))throw fail(403,'Perfil fora do laboratório');
    return user;
  }
  const send=(res,status,response,success=status<400)=>{
    res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'});
    const mapsResponse=response?.status && (Array.isArray(response.results)||Array.isArray(response.predictions));
    res.end(JSON.stringify(success?{...(mapsResponse?response:{}),success:true,response}:{success:false,errors:[response]}));
  };
  const server=http.createServer(async(req,res)=>{
    let path='',credentialState,offerState;
    const shape=value=>value===undefined?'missing':value===''?'empty':typeof value==='string'&&/^[a-f0-9]{64}$/.test(value)?'opaque64':'other';
    try{
      // Treat //route as an HTTP path, never a protocol-relative URL/authority.
      const url=new URL(req.url.replace(/^\/{2,}/,'/'),'http://localhost');path=url.pathname.replace(/^\/api(?=\/|$)/,'')||'/';
      if(req.method==='GET'&&path==='/health'){await pool.query('SELECT 1');return send(res,200,{service:'alce-legacy',status:'ok'});}
      if(now()>=expiration)throw fail(503,'Janela de laboratório encerrada');
      if(!['GET','POST'].includes(req.method))throw fail(405,'Método não suportado');
      const ip=req.socket.remoteAddress,time=now();
      for(const [key,bucket] of buckets)if(bucket.until<=time)buckets.delete(key);
      const auth=['/taxista/login','/passageiro/login20','/lab/pair/driver','/lab/pair/passenger'].includes(path);
      const bucketKey=(auth?'auth:':'api:')+ip;
      if(!buckets.has(bucketKey))buckets.set(bucketKey,{count:0,until:time+60000});
      if(++buckets.get(bucketKey).count>(auth?10:180))throw fail(429,'Limite de requisições atingido');
      const maxBytes=path==='/solicitacao/enviarDadosPendentes'?384*1024:
        ['/solicitacao/finalizar','/solicitacao/finalizarTrajeto'].includes(path)?64*1024:20000;
      const body=await read(req,url,maxBytes);
      if(auth){
        if(req.method!=='POST')throw fail(405,'Login exige POST');
        const role=path.includes('taxista')||path.endsWith('/driver')?'driver':'passenger';
        const code=body.code??body.senha;
        const session=await pairing({code},role);const user=await ownUser(session.token);requireRole(user,role);
        const vehicle=role==='driver'?(await pool.query('SELECT plate,model,color FROM vehicles WHERE driver_id=$1',[user.id])).rows[0]:{};
        const legacy={...await loginModel(user,session.token,ids,vehicle),expires_at:session.expiresAt};
        return send(res,200,path.startsWith('/lab/')?{...session,profile:legacy}:legacy);
      }
      if(path==='/passageiro/informacoes'&&req.method==='GET'){res.writeHead(200,{'content-type':'text/html; charset=utf-8','content-security-policy':"default-src 'none'; style-src 'unsafe-inline'"});return res.end('<!doctype html><html lang="pt-BR"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Alce Yatri Brasil</title><body style="font:20px sans-serif;color:#4A153B;padding:24px"><h1>Alce Yatri Brasil</h1><p>Confira seu destino e o ponto de embarque ao confirmar a viagem.</p><p>Use o chat da corrida para combinar o encontro com seu motorista.</p></body></html>');}
      if(path==='/passageiro/bannerImagem'&&req.method==='GET'&&banners){
        const data=await banners.image(url.searchParams.get('id'));res.writeHead(200,{'content-type':'image/png','cache-control':'public,max-age=300','x-content-type-options':'nosniff'});return res.end(data);
      }
      if(path==='/configuracao'||path==='/configuracao/passageiro'){
        const config=configuration(path==='/configuracao'?'driver':'passenger',androidMapsKey);
        if(banners&&path.endsWith('/passageiro'))config.anuncios=await banners.list();
        return send(res,200,config);
      }
      if(path==='/passageiro/verificarLogin')
        return send(res,200,{proxima_etapa:'S',permitir_recuperacao_senha:false,bandeira_id:1,data:null,migracao:false,telefone:null});
      if(path==='/passageiro/personalizacaoApp')
        return send(res,200,{cor_app:'#FF00AA',tipo_marcador_utilizado:'2',
          tela_inicial:{estilo_tela:'F',marca:{estilo_imagem:'A',nome_exibicao:null,url_imagem:null},recursos:[{tipo:'S',ordem:1}]}});
      const authHeader=req.headers.authorization;
      const token=(authHeader?.startsWith('Bearer ')?authHeader.slice(7):'') ||
        req.headers['x-session-token'] || req.headers['temporary-access-token'];
      if(path.includes('/maps/api/'))credentialState={bearer:shape(authHeader?.startsWith('Bearer ')?authHeader.slice(7):undefined),session:shape(req.headers['x-session-token']),temporary:shape(req.headers['temporary-access-token'])};
      const user=await ownUser(token);
      const actorId=await ids.number('user',user.id);
      const sentId=user.role==='driver'?body.taxista_id:body.cliente_id;
      if(sentId!==undefined&&String(sentId)!==String(actorId))throw fail(403,'Identidade não corresponde à sessão');
      let result;
      if(path.startsWith('/endereco/')||path.startsWith('/alce/addresses/')){
        requireRole(user,'passenger');if(!addresses)throw fail(503,'Endereços temporariamente indisponíveis');
        result=await addresses.handle({path,body,user,method:req.method});
      }else if(path.startsWith('/mensagem/')){
        if(!chat)throw fail(503,'Chat temporariamente indisponível');
        if(path==='/mensagem/listaConversas')result=await chat.conversations(user);
        else if(path==='/mensagem/conversaSolicitacao')result=await chat.conversation(user,body);
        else if(path==='/mensagem/enviaMensagem'){if(req.method!=='POST')throw fail(405,'Envio exige POST');result=await chat.send(user,body);}
        else if(path==='/mensagem/listaMensagens')result=await chat.messages(user,body);
        else if(path==='/mensagem/listaAnteriores')result=await chat.messages(user,body,true);
        else throw fail(404,'Operação de mensagem indisponível');
      }else if(path==='/passageiro/registrarInteracaoAnuncio'){
        requireRole(user,'passenger');if(!banners)throw fail(503,'Banners indisponíveis');if(!['clique','exibicao'].includes(body.acao))throw fail(400,'Interação inválida');result=await banners.interaction(body.anuncio_id,body.acao==='clique');
      }else if(path.endsWith('/maps/api/place/autocomplete/json')){
        const at=body.location?String(body.location).split(','):null;
        const found=await maps.autocomplete(body.input,at?{lat:number(at[0],90),lng:number(at[1],180)}:undefined);
        result={status:'OK',predictions:found.suggestions.map(s=>({description:s.address,place_id:s.placeId,
          reference:s.placeId,structured_formatting:{main_text:s.address,secondary_text:''},matched_substrings:[],terms:[],types:[]}))};
      }else if(path.endsWith('/maps/api/geocode/json')){
        let found;
        if(body.placeid||body.place_id)found=await maps.details(body.placeid||body.place_id);
        else if(body.latlng){const at=String(body.latlng).split(',');found=await maps.reverse({lat:number(at[0],90),lng:number(at[1],180)});}
        else throw fail(422,'Selecione um endereço da pesquisa ou informe coordenadas');
        // Details are requested after the passenger chooses a suggestion. Do
        // not record autocomplete keystrokes or the home GPS reverse lookup.
        if(addresses&&user.role==='passenger'&&(body.placeid||body.place_id)){
          const components=found.addressComponents||[];
          const part=(types,short=false)=>{const c=components.find(c=>c.types?.some(t=>types.includes(t)));return c?.[short?'short_name':'long_name']||'';};
          await addresses.save(user,{endereco:found.address,lat:found.location.lat,lng:found.location.lng,
            nome_cidade:part(['administrative_area_level_2','locality']),nome_uf:part(['administrative_area_level_1'],true),
            bairro:part(['sublocality','sublocality_level_1','neighborhood'])},{remember:true});
        }
        result={status:'OK',results:[{formatted_address:found.address,geometry:{location:found.location},
          place_id:found.placeId||'',address_components:found.addressComponents||[],types:[],...(found.attribution?{attribution:found.attribution}:{})}]};
      }else if(path==='/taxi/proximos'){
        requireRole(user,'passenger');
        result=await nearby(user,{lat:number(body.lat,90),lng:number(body.lng,180),bandeira_configuracao_id:body.bandeira_configuracao_id});
      }else if(path==='/solicitacao/historico'){
        if(!reporting)throw fail(503,'Histórico temporariamente indisponível');
        result=await reporting.history(user,body);
      }else if(['/taxista/obterGanhos','/taxista/resumoGanhos'].includes(path)){
        requireRole(user,'driver');if(!reporting)throw fail(503,'Ganhos temporariamente indisponíveis');
        result=await reporting.earnings(user,body,path==='/taxista/obterGanhos');
      }else if(path==='/taxista/obterDadosTaxista'){
        requireRole(user,'driver');
        const vehicle=(await pool.query('SELECT plate,model,color FROM vehicles WHERE driver_id=$1',[user.id])).rows[0];
        result={...await loginModel(user,token,ids,vehicle),status_cadastro:'A',status_vencimento_cnh:'D',
          permitir_login_aguardando_ativacao:false,permitir_vencimento_cnh_taxista:true,
          permitir_notificacoes_automaticas:false,permitir_fila_espera:false,posicao_fila_espera:0};
      }else if(path==='/taxi/status'){
        requireRole(user,'driver');if(req.method!=='POST')throw fail(405,'Status exige POST');
        if(!['L','O'].includes(body.status))throw fail(400,'Status inválido');
        await service.availability(user,{available:body.status==='L'});result={force_logout:false,status:body.status};
      }else if(path==='/taxi/posicao'){
        requireRole(user,'driver');await service.location(user,{lat:number(body.lat,90),lng:number(body.lng,180)});result={};
      }else if(path==='/solicitacao20/estimativasCorrida'){
        requireRole(user,'passenger');if(req.method!=='POST')throw fail(405,'Estimativa exige POST');
        const quote=await service.quote(user,points(body));result=await estimateModel(quote,ids);
      }else if(path==='/solicitacao20/nova'){
        requireRole(user,'passenger');if(req.method!=='POST')throw fail(405,'Solicitação exige POST');
        const details=object(body.solicitacao);
        if(details.paradas?.length)throw fail(422,'Paradas ainda não suportadas neste piloto');
        const quoteId=await ids.uuid('quote',details.estimativa_id);
        const {id}=await service.requestRide(user,{quoteId});const ride=await service.ride(user,id);
        result={id:await ids.number('ride',id),statusSolicitacao:statusObject(ride.status),tipo_condutor:'T',pagamentoStripe:null};
      }else if(['/solicitacao20/listaDisponiveis','/solicitacao20/listaPendentes'].includes(path)){
        requireRole(user,'driver');const snapshot=await service.snapshot(user);
        const available=await Promise.all(snapshot.offers.map(async ride=>{
          const events=await pool.query("SELECT id,created_at FROM events WHERE user_id=$1 AND kind='offer.created' AND payload->>'rideId'=$2 ORDER BY id DESC LIMIT 1",[user.id,ride.id]);
          return driverOfferModel(ride,ids,events.rows[0],actorId);
        }));
        result={disponiveis:available,tld:'5',pendentes_ids:[],programadas:'0',hash_pendentes:'',hash_programadas:'',negociacoes:[]};
        offerState={available:snapshot.available,online:snapshot.online,count:available.length};
      }else if(path==='/solicitacao/detalhesTaxista'){
        requireRole(user,'passenger');
        const ride=await service.ride(user,await ids.uuid('ride',body.id));
        if(!ride.driver_id)throw fail(409,'A corrida ainda não tem motorista atribuído');
        const model=await rideModel(ride,ids);result={taxista:model.taxista,avaliacao:0};
      }else if(['/motivoCancelamento/cliente20','/motivoCancelamento/taxista'].includes(path)){
        const passenger=path.endsWith('/cliente20');requireRole(user,passenger?'passenger':'driver');
        const ride=await service.ride(user,await ids.uuid('ride',rideReference(body)));
        if(!['searching','accepted','arrived'].includes(ride.status))throw fail(409,'Não é possível cancelar neste estado');
        // Own lab policy: no cancellation fee or redispatch. The final command
        // still revalidates the persisted state transactionally in the engine.
        const reasons=[{id:1,motivo:passenger?'Não preciso mais da corrida':'Imprevisto com o veículo',categoria:null,solicitar_impulsionamento:false}];
        result=passenger?{motivos:reasons,taxa_cancelamento:0}:
          reasons.map(m=>({id:String(m.id),motivo:m.motivo,condicao_cancelamento:'L'}));
      }else if(path==='/solicitacao20/detalhes'){
        requireRole(user,'driver');
        const ride=await service.ride(user,await ids.uuid('ride',body.id));
        result=await driverRideModel(ride,ids);
      }else if(path==='/solicitacao20/recalculoRota'){
        requireRole(user,'passenger');const id=await ids.uuid('ride',rideReference(body));
        const ride=await service.ride(user,id);const navigation=await service.navigation(user,id);
        const target=navigation.leg==='pickup'?ride.origin:ride.destination;
        result={status_solicitacao:statusCode(ride.status),qtd_recalculo_rota:0,qtd_recalculo_rota_em_andamento:0,
          rota_polyline:navigation.route.encodedPolyline,lat_taxista:ride.driver_lat,lng_taxista:ride.driver_lng,
          lat_destino_taxi_rota:target.lat,lng_destino_taxi_rota:target.lng,
          rota_paradas:[],duracao_rota_segundos:navigation.route.durationSeconds};
      }else if(['/solicitacao20/ativa','/solicitacao20/index','/solicitacao30/ativa','/solicitacao30/status'].includes(path)){
        const snapshot=await service.snapshot(user);
        const ride=body.id?await service.ride(user,await ids.uuid('ride',body.id)):snapshot.rides[0];
        const model=ride?await (user.role==='driver'?driverRideModel:rideModel)(ride,ids):null;
        // WaitingDriverHeader force-unwraps ETA. Supply the actual pickup route
        // before exposing accepted state; never substitute total trip duration.
        if(model&&user.role==='passenger'&&['accepted','arrived'].includes(ride.status)){
          const nullableEta=typeof body.versao==='string'&&(body.versao==='A28L7'||/^28\.9-alce-lab([7-9]|[1-9][0-9]+)$/.test(body.versao));
          if(nullableEta&&ride.status==='arrived'){
            // Driver already confirmed arrival; remaining pickup time is zero.
            // This is state, not a fabricated GPS route or distance measurement.
            model.estimativa_segundos_passageiro=0;
          }else try{
            const navigation=await service.navigation(user,ride.id);
            model.estimativa_segundos_passageiro=Math.ceil(navigation.route.durationSeconds);
            model.estimativa_km_passageiro=navigation.route.distanceMeters/1000;
          }catch(error){
            const stale=error.status===409&&error.message==='Localização do motorista desatualizada';
            if(!nullableEta||(!stale&&error.status!==502))throw error;
            // Lab 7 hides the unavailable ETA while preserving the actual ride
            // state. Old clients retain their error contract until upgraded.
            model.estimativa_segundos_passageiro=null;
            model.estimativa_disponivel=false;
          }
        }
        result=path.startsWith('/solicitacao30/')?{solicitacoes:model?[{...model,statusSolicitacao_status:model.status}]:[],tempoPolling:5}:model;
      }else if(path==='/solicitacao/enviarDadosPendentes'){
        requireRole(user,'driver');if(req.method!=='POST')throw fail(405,'Pendências exigem POST');
        if(!saveReceipt)throw fail(503,'Persistência de finalização indisponível');
        let batch=body.dadosSolicitacoes;
        if(typeof batch==='string'){try{batch=JSON.parse(batch);}catch{throw fail(400,'Lista de pendências inválida');}}
        if(!Array.isArray(batch)||batch.length<1||batch.length>10)throw fail(400,'Envie de uma a dez finalizações');
        // Validate references before processing. If any operation fails, no
        // success ack is sent: the original app retains the whole batch.
        const pending=[];
        for(const item of batch){
          const details=object(item);
          if(details.taxista_id!==undefined&&String(details.taxista_id)!==String(actorId))throw fail(403,'Identidade não corresponde à sessão');
          pending.push({details,id:await ids.uuid('ride',details.id)});
        }
        for(const item of pending)await saveReceipt(user,item.id,item.details);
        result={recebidas:pending.length};
      }else if(['/solicitacao/aceitar','/solicitacao/registroCorrida','/solicitacao/finalizar','/solicitacao/finalizarTrajeto','/solicitacao/cancelamento'].includes(path)){
        if(req.method!=='POST')throw fail(405,'Ação exige POST');
        const details=path==='/solicitacao/finalizar'&&body.solicitacao!==undefined?object(body.solicitacao):undefined;
        if(details?.taxista_id!==undefined&&String(details.taxista_id)!==String(actorId))throw fail(403,'Identidade não corresponde à sessão');
        const id=await ids.uuid('ride',rideReference(body,details));
        if(path==='/solicitacao/aceitar'){
          requireRole(user,'driver');await service.accept(user,id);const ride=await service.ride(user,id);
          result={status_aceite:'V',dados_solicitacao:await driverRideModel(ride,ids),message:'',tempo_espera:0};
        }else{
          if(path==='/solicitacao/cancelamento'&&[1,'1',true,'true'].includes(body.redespachar))
            throw fail(422,'Redespacho ainda não integrado; cancele e solicite outra corrida');
          const action=path==='/solicitacao/cancelamento'?'cancel':path==='/solicitacao/registroCorrida'?{C:'arrive',E:'start'}[body.registro]:'complete';
          if(!action)throw fail(422,'Evento de corrida ainda não suportado');
          if(path==='/solicitacao/finalizar'){
            requireRole(user,'driver');if(!saveReceipt)throw fail(503,'Persistência de finalização indisponível');
            await saveReceipt(user,id,details??body);
          }else await service.change(user,id,action);
          const ride=await service.ride(user,id);
          if(path==='/solicitacao/finalizarTrajeto'){
            // Native FinalizarTrajetoJson reads valor/valor_integral, not valor_corrida.
            // Preserve the engine's fixed quote. Client meter values never set fare.
            result={...await rideModel(ride,ids),valor:ride.fare_cents/100,valor_integral:ride.fare_cents/100,
              valor_cupom:0,valor_desconto:0,substituir_valor_prefixado:false};
          }else if(path==='/solicitacao/finalizar'){
            requireRole(user,'driver');
            result={...await rideModel(ride,ids),ganhos_motorista:(ride.fare_cents/100).toFixed(2),status_pagamento:null};
          }else result=path==='/solicitacao/registroCorrida'?{solicitacao_paradas:[],status_solicitacao:statusObject(ride.status)}:await rideModel(ride,ids);
        }
      }else if(path==='/lab/logout'){
        await service.logout(token);result={};
      }else throw fail(501,'Operação ainda não integrada ao laboratório');
      send(res,200,result);
      audit({method:req.method,path,status:200,...(credentialState?{credentialState}:{}),...(offerState?{offerState}:{})});
    }catch(error){
      if(error.code==='23505'&&['passenger_one_active','driver_one_active'].includes(error.constraint))
        error=fail(409,'Já existe uma corrida ativa para este perfil');
      const status=Number.isInteger(error.status)&&error.status>=400&&error.status<600?error.status:503;
      send(res,status,status===503?'Serviço temporariamente indisponível':error.message);
      // Sem valores de credenciais: somente caminho sem query, status e classificação de presença/formato.
      audit({method:req.method,path,status,...(credentialState?{credentialState}:{})});
    }
  });
  server.headersTimeout=15000;server.requestTimeout=20000;return server;
}
