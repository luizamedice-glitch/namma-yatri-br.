// SPDX-License-Identifier: AGPL-3.0-or-later
// One persisted conversation per existing ride; its legacy ID is the ride's ID.
const fail=(status,message)=>Object.assign(new Error(message),{status});
const terminal=status=>['completed','cancelled'].includes(status);
const cursor=value=>{
 if(value===undefined||value===null||value===''||String(value)==='-1')return '0';
 if(!/^\d{1,16}$/.test(String(value))||!Number.isSafeInteger(Number(value)))throw fail(400,'Sequencial inválido');
 return String(Number(value));
};
export function chatService({pool,service,ids}){
 async function rideFor(user,legacy){
  const ride=await service.ride(user,await ids.uuid('ride',legacy));
  if(!ride.driver_id||!(user.role==='passenger'&&ride.passenger_id===user.id||user.role==='driver'&&ride.driver_id===user.id))throw fail(403,'Conversa restrita aos participantes da corrida');
  return ride;
 }
 const model=(m,user)=>({au:m.sender_role==='driver'?'Motorista - '+m.sender_name:m.sender_name,tu:m.sender_role==='passenger'?'2':'3',
  dt:new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).format(new Date(m.created_at)),
  tx:m.text,sq:String(m.id).padStart(16,'0'),eu:m.sender_id===user.id});
 async function list(user,ride,body={},older=false){
  const recent=!older&&body.ultima===undefined;
  const seq=cursor(older?body.primeira??body.ultima:body.ultima);
  const rows=await pool.query(`SELECT m.*,u.name AS sender_name,u.role AS sender_role FROM alce_chat_messages m JOIN users u ON u.id=m.sender_id WHERE m.ride_id=$1 ${older?'AND m.id<$2': 'AND m.id>$2'} ORDER BY m.id ${older||recent?'DESC':'ASC'} LIMIT 100`,[ride.id,older&&seq==='0'?'9007199254740991':seq]);
  return (recent?rows.rows.reverse():rows.rows).map(m=>model(m,user));
 }
 return {
  async initialize(){await pool.query(`CREATE TABLE IF NOT EXISTS alce_chat_messages (
   id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
   ride_id uuid NOT NULL REFERENCES rides(id),sender_id uuid NOT NULL REFERENCES users(id),
   text text NOT NULL CHECK(char_length(text) BETWEEN 1 AND 2000),client_key text,
   created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(ride_id,sender_id,client_key));
   CREATE INDEX IF NOT EXISTS alce_chat_messages_ride_seq ON alce_chat_messages(ride_id,id)`);},
  async conversations(user){
   const rows=await pool.query(`SELECT r.id,r.status,coalesce(max(m.id),0)::text AS seq
    FROM rides r LEFT JOIN alce_chat_messages m ON m.ride_id=r.id
    WHERE r.driver_id IS NOT NULL AND (r.passenger_id=$1 OR r.driver_id=$1)
    GROUP BY r.id HAVING count(m.id)>0 OR r.status IN ('accepted','arrived','in_progress')
    ORDER BY max(m.created_at) DESC NULLS LAST,r.created_at DESC LIMIT 100`,[user.id]);
   return Promise.all(rows.rows.map(async r=>{const id=String(await ids.number('ride',r.id));return {
    id,solicitacao_id:id,assunto:'Conversa da corrida',tipo:user.role==='driver'?'2':'3',
    ultimo_sequencial:String(r.seq).padStart(16,'0'),nao_lidas:'0',encerrada:terminal(r.status)
   };}));
  },
  async conversation(user,body){
   const ride=await rideFor(user,body.solicitacao_id??body.conversa_id);
   const messages=await list(user,ride,{},false);
   const last=await pool.query('SELECT coalesce(max(id),0)::text AS seq FROM alce_chat_messages WHERE ride_id=$1',[ride.id]);
   return {id:String(await ids.number('ride',ride.id)),solicitacao_id:String(await ids.number('ride',ride.id)),assunto:'Conversa da corrida',tipo:'2',mensagens:messages,
    ultimo_sequencial:String(last.rows[0].seq).padStart(16,'0'),nao_lidas:'0',encerrada:terminal(ride.status)};
  },
  async messages(user,body,older=false){return list(user,await rideFor(user,body.conversa_id),body,older);},
  async send(user,body){
   const text=typeof body.texto==='string'?body.texto.trim():'';
   if(!text||[...text].length>2000||/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(text))throw fail(400,'Informe uma mensagem de até 2000 caracteres');
   const key=body.client_message_id??null;
   if(key!==null&&(typeof key!=='string'||!/^[a-zA-Z0-9_-]{8,80}$/.test(key)))throw fail(400,'Identificador de mensagem inválido');
   const ride=await rideFor(user,body.conversa_id);
   // Lock the authoritative ride row so completion/cancellation cannot race a send.
   const client=await pool.connect();
   try{
    await client.query('BEGIN');
    const current=await client.query('SELECT status,driver_id,passenger_id FROM rides WHERE id=$1 FOR UPDATE',[ride.id]);
    const r=current.rows[0];
    if(!r||terminal(r.status)||!['accepted','arrived','in_progress'].includes(r.status))throw fail(409,'Conversa encerrada para novas mensagens');
    if(user.id!==(user.role==='driver'?r.driver_id:r.passenger_id))throw fail(403,'Participante inválido');
    const inserted=await client.query(`INSERT INTO alce_chat_messages(ride_id,sender_id,text,client_key) VALUES($1,$2,$3,$4)
     ON CONFLICT(ride_id,sender_id,client_key) DO UPDATE SET client_key=excluded.client_key RETURNING id,text`,[ride.id,user.id,text,key]);
    if(inserted.rows[0].text!==text)throw fail(409,'Identificador já usado para outra mensagem');
    await client.query('COMMIT');
   }catch(e){try{await client.query('ROLLBACK');}catch{}throw e;}finally{client.release();}
   return list(user,ride,body);
  }
 };
}
