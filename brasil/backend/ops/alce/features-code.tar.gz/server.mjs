// SPDX-License-Identifier: AGPL-3.0-or-later
// Executado dentro da imagem Namma existente: nenhum domínio é copiado.
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';
import {legacyIds} from './ids.mjs';
import {createLegacyApi} from './http.mjs';
import {receiptStore} from './receipts.mjs';
import {reportingService} from './reporting.mjs';
import {chatService} from './chat.mjs';
import {addressService} from './addresses.mjs';
import {bannerService} from './banners.mjs';
import {readFile} from 'node:fs/promises';
const env=process.env;
if(env.NODE_ENV!=='development'||env.ALCE_ISOLATED_MODE!=='true'||new URL(env.DATABASE_URL).pathname!=='/alce_lab')
  throw Error('ISOLATED_ALCE_DATABASE_REQUIRED');
const root=env.NAMMA_BACKEND_ROOT||'/app';
const load=name=>import(pathToFileURL(resolve(root,'src',name+'.mjs')).href);
const {connectDatabase,transaction}=await load('db');
const {mobilityService}=await load('mobility');
const {mapsService}=await load('maps');
const {exchangePairing}=await load('driver-pairing');
const {driverPilotId,passengerPilotId}=await load('driver-pilot');
const pool=await connectDatabase(env.DATABASE_URL);
const maps=mapsService({key:env.GOOGLE_MAPS_SERVER_KEY,geoapifyKey:env.GEOAPIFY_API_KEY,
  baseFareCents:Number(env.BASE_FARE_CENTS||500),perKmCents:Number(env.PER_KM_CENTS||200)});
const service=mobilityService(pool,maps,{allowDevelopmentAccounts:true});
const ids=legacyIds(pool);await ids.initialize();
const chat=chatService({pool,service,ids});await chat.initialize();
const addresses=addressService({pool,ids,transaction});await addresses.initialize();
const banners=bannerService({pool});await banners.initialize();
for(const campaign of JSON.parse(await readFile(new URL('./campaign-seeds.json',import.meta.url),'utf8')))await banners.save(campaign,{insertOnly:true});
const server=createLegacyApi({pool,service,ids,maps,chat,banners,addresses,reporting:reportingService({pool,service,ids}),saveReceipt:receiptStore({pool,service,transaction}),pairing:(body,role)=>exchangePairing(pool,body,role),
  until:env.YATRI_DRIVER_PILOT_UNTIL,allowedIds:[driverPilotId,passengerPilotId],
  androidMapsKey:env.ALCE_ANDROID_MAPS_KEY||'',
  audit:event=>console.log(JSON.stringify({event:'legacy_request',...event}))});
server.listen(Number(env.ALCE_LEGACY_PORT||8084),env.HOST||'127.0.0.1',()=>console.log('Alce compatibility ready'));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{
  server.close(async()=>{await pool.end();process.exit(0);});
});
