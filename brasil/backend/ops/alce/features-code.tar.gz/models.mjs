// SPDX-License-Identifier: AGPL-3.0-or-later
import {readFile} from 'node:fs/promises';
const defaults=JSON.parse(await readFile(new URL('./model-defaults.json',import.meta.url),'utf8'));
export const statusCode = status => ({searching:'D',accepted:'A',arrived:'A',in_progress:'E',completed:'F',cancelled:'C'})[status];
const statusName = status => ({searching:'Buscando motorista',accepted:'Motorista a caminho',arrived:'Motorista chegou',in_progress:'Em andamento',completed:'Finalizada',cancelled:'Cancelada'})[status];
export const statusObject = status => ({status:statusCode(status),mensagem_cliente:''});
// Flutter casts registroCorrida.nome to non-null String before decoding registro.
// C signals pickup arrival; E is the driver's boarding event, not Flutter's
// A (arredores). The passenger enters the trip through statusSolicitacao E.
const rideRegistration = status => status==='arrived'?{registro:'C',nome:'Motorista chegou ao local de embarque'}:
  status==='in_progress'?{registro:'E',nome:'Passageiro embarcou'}:null;
export function configuration(role, androidMapsKey='') {
  const config=structuredClone(defaults[role==='driver'?'driverConfig':'passengerConfig']);
  return Object.assign(config,{bandeira_id:1,nome_bandeira:'AlceYatri',nome_cidade:'Laboratório',
    chave_google_api:androidMapsKey,cor_app:'#FF00AA',sigla_moeda:'R$',sigla_pais:'BR',tipo_bandeira:'T',
    autocomplete_delay:300,adquirir_session_token:false,renovar_token_push:false,
    tipo_marcador_utilizado:'2',exibir_marcador_direcional:true,tempo_desconexao_condutor:60,
    login_por_telefone_padrao:false,possui_cadastro_completo:true,exibir_mapa_app_taxista:'S',
    exibir_enderecos_apos_aceite:true,exibir_valores_condutor:true,tempo_polling:600000,
    tp_status_l:5,tp_status_o:5,tempo_polling_pendencias:5,tempo_espera:role==='driver'?'60':'0',tempo_inatividade_taxista_alerta:'0',
    data_hoje:new Date().toISOString().slice(0,10),tipo_pagamento:[{id:1,nome:'Dinheiro',tipo:'D'}]});
}
export async function loginModel(user,token,ids,vehicle={}) {
  const id=await ids.number('user',user.id);
  if(user.role==='passenger')return {...structuredClone(defaults.passengerLogin),id,nome:user.name,
    email:'',telefone:'',temporary_access_token:token,cliente_validado:true,status_cliente:'A'};
  return {id:String(id),nome:user.name,status_taxista:'A',api_token:token,bandeira_id:'1',nome_bandeira:'AlceYatri',
    placa:vehicle.plate||'',modelo:vehicle.model||'',cor:vehicle.color||'',ano_modelo:'',
    categorias:['1'],filtros_pagamento:[],filtros_solicitacao:[],id_ultima_notificacao:0,
    pagamento_via_app_obrigatorio:false,desconto_maximo:0,dados_mensagem:{mensagem_nao_lida_id:'',
      conversa_nao_lida_id:'',ultimo_sequencial:'0',ultimo_sequencial_lido:'0'}};
}
export async function estimateModel(quote, ids) {
  const amount=quote.fareCents/100;
  const payment={valor_estimativa:amount,valor_estimativa_sem_desconto:amount,estimativa_valor_sem_desconto:amount,
    valor_minimo:amount,valor_maximo:amount,perc_desconto:0,diferenca_desconto:0,qtd_motoristas:0};
  return {...structuredClone(defaults.estimate),estimativa_id:await ids.number('quote',quote.id),
    estimativa_km:quote.route.distanceMeters/1000,estimativa_minutos:quote.route.durationSeconds/60,
    rota_polyline:quote.route.encodedPolyline,sigla_moeda:'R$',exibir_estimativa_corrida:true,estimativa_prefixada_app:true,
    tipos_pagamento:[{id:1,nome:'Dinheiro',tipo:'D',url_icone:null,permitir_cashback:false,permitir_pagamento_creditos:false,exibir_observacao_app:false}],
    categorias:[{...structuredClone(defaults.category),id:1,nome:'AlceYatri',descricao:'Corrida de laboratório',
      maximo_passageiros:4,permitir_solicitacao_imediata:true,estimativa_original:amount,
      estimativa_pagamentos:{D:[payment]}}]};
}
export async function rideModel(ride,ids) {
  const id=await ids.number('ride',ride.id);
  const passenger=await ids.number('user',ride.passenger_id);
  const driver=ride.driver_id?await ids.number('user',ride.driver_id):null;
  const from=ride.origin,to=ride.destination,amount=ride.fare_cents/100;
  return {id,cliente_id:passenger,taxista_id:driver,status:statusCode(ride.status),
    statusSolicitacao:statusObject(ride.status),nome:statusName(ride.status),tipo_condutor:'T',metodo_calculo_corrida:'R',
    registro_corrida:ride.status==='arrived'?'C':ride.status==='in_progress'?'E':null,
    nome_cliente:ride.passenger_name,nome_passageiro:ride.passenger_name,nome_taxista:ride.driver_name,
    placa:ride.plate,modelo:ride.model,cor:ride.color,
    lat_partida:from.lat,lng_partida:from.lng,endereco_partida:from.address,
    lat_desejado:to.lat,lng_desejado:to.lng,endereco_desejado:to.address,endereco_destino:to.address,
    lat_taxista:ride.driver_lat,lng_taxista:ride.driver_lng,lat_taxi:ride.driver_lat,lng_taxi:ride.driver_lng,
    tempo_posicao_taxi:ride.driver_location_at?Math.max(0,Math.floor((Date.now()-new Date(ride.driver_location_at))/1000)):null,
    tempo_atualizacao:3,bandeira_id:1,bandeira_configuracao_id:1,solicitacaoParadas:[],eventoSolicitacaos:[],
    exibir_rota_status_aceita:true,exibir_rota_status_em_andamento:true,
    registroCorrida:rideRegistration(ride.status),
    estimativa_valor:String(amount.toFixed(2)),valor_corrida:String(amount.toFixed(2)),valor_estimativa:amount,valor_total:amount,
    estimativa_km:ride.route.distanceMeters/1000,estimativa_minutos:ride.route.durationSeconds/60,
    rota_polyline:ride.route.encodedPolyline,tipo_pagamento:'D',nome_categoria:'AlceYatri',
    data_hora_solicitacao:new Date(ride.created_at).toISOString(),paradas:[],observacao:'',
    cliente:{id:String(passenger),nome:ride.passenger_name,telefone:''},
    taxista:driver?{id:driver,nome:ride.driver_name,telefone:'',status_taxi:'O',avaliacao_media:0,
      veiculo:{placa:ride.plate,modelo:ride.model,cor:ride.color,nome_cor:ride.color},placa:ride.plate,modelo:ride.model,cor:ride.color}:null};
}

// Accepted-driver details are a different wire model from passenger polling and
// the offer list. The original updateFromDetalhesCorrida dereferences these
// containers/counters directly; their absence breaks both acceptance and reopen.
export async function driverRideModel(ride,ids) {
  const model=await rideModel(ride,ids);
  const time=Object.fromEntries(new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',
    year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'})
    .formatToParts(new Date(ride.created_at)).map(p=>[p.type,p.value]));
  return {...model,tipo_operacao:'P',solicitacao_via_app:true,cliente_especificou_taxista:false,
    data_hora_solicitacao:`${time.year}-${time.month}-${time.day} ${time.hour}:${time.minute}:${time.second}`,
    statusSolicitacao:{...model.statusSolicitacao,nome:statusName(ride.status),requer_valor:false,requer_obs:false},
    destino_direcionado:false,metodo_calculo_corrida:'R',tipo_pagamento_tipo:'D',
    qtd_paradas_adicionais:0,trajeto_alterado:0,duracao_aceite:0,duracao_em_andamento:0,
    permite_mensagem_cliente:true,solicitacao_macaneta:false,passou_arredores_local:false,ligacao_via_integracao:false,
    duracao_em_andamento_min:0,tempo_total_coleta_segundos:0,retorno:false,
    solicitacao_paradas:[],solicitacao_valor_detalhes:[],taxas_bandeiras:[],
    perc_desconto:0,valor_desconto:'0.00',valor_cupom:'0.00',valor_ganho:model.valor_corrida,
    valor_corrida_integral:model.valor_corrida,exibir_valor_corrida:true,
    bandeira_chamada:{nome:'AlceYatri',tipo_taximetro:'V',exibir_valores_condutor:true,
      permitir_cancelamento_taxista:'S',permitir_taxista_avaliar_cliente:false,
      permitir_taxista_bloquear_cliente:false,tempo_espera_partida:0,raio_tempo_espera_partida:0},
    tarifaCategoria:{id:1,nome:'AlceYatri',valor_minimo:ride.fare_cents/100,valor_km:0,
      valor_minuto:0,valor_bandeirada:0,valor_hora_parada:0,valor_parada_adicional:0,valor_tabelado:[]},
    registroCorrida:model.registroCorrida??{registro:null,nome:null,nome_en:null,nome_es:null},
    motivoCancelamento:{id:'',motivo:'',motivo_en:'',motivo_es:''},
    cliente:{...model.cliente,nome_razao:ride.passenger_name,tipo_cliente:'F'}};
}

// The original driver accesses eventoSolicitacaos[0] before opening acceptance.
// Use the actual offer.created event for this authenticated recipient; do not
// fabricate an event or expose another driver's offer metadata.
export async function driverOfferModel(ride,ids,event,driverId) {
  if(!event?.id||!event?.created_at)throw Error('PERSISTED_OFFER_EVENT_REQUIRED');
  const model=await rideModel(ride,ids);
  const parts=Object.fromEntries(new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',
    year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'})
    .formatToParts(new Date(event.created_at)).map(p=>[p.type,p.value]));
  const timestamp=`${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}:${parts.second}`;
  return {...model,destino_direcionado:false,solicitacao_via_app:true,cliente_especificou_taxista:false,
    tipo_operacao:'P',valor_ganho:ride.fare_cents/100,estimativa_tempo_minutos:Math.ceil(ride.route.durationSeconds/60),
    qtd_paradas:'0',eventoSolicitacaos:[{id:String(event.id),data_hora:timestamp,
      taxistaEventoSolicitacaos:[{id:String(event.id),taxista_id:String(driverId)}]}]};
}
