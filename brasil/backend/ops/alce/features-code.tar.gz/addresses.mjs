// SPDX-License-Identifier: AGPL-3.0-or-later
import {createHash} from 'node:crypto';
const fail=(status,message)=>Object.assign(new Error(message),{status});
const check=(v,s,m)=>{if(!v)throw fail(s,m);};
const passenger=u=>check(u.role==='passenger',403,'Somente passageiro');
const text=(v,max,optional=false)=>{if(optional&&v==null)return '';check(typeof v==='string'&&v.trim().length<=max&&(optional||v.trim().length),400,'Texto inválido');return v.trim();};
const coordinate=(v,max)=>{check(['number','string'].includes(typeof v)&&String(v).trim()!==''&&Number.isFinite(Number(v))&&Math.abs(Number(v))<=max,400,'Coordenadas inválidas');return Number(v);};
function object(v){try{if(typeof v==='string')v=JSON.parse(v);}catch{throw fail(400,'Endereço inválido');}check(v&&typeof v==='object'&&!Array.isArray(v),400,'Endereço inválido');return v;}
const key=v=>createHash('sha256').update(JSON.stringify([v.address.normalize('NFKC').toLocaleLowerCase('pt-BR'),v.lat.toFixed(5),v.lng.toFixed(5)])).digest('hex');
const slots=new Set(['Casa','Trabalho','Escola']);
export function addressService({pool,ids,transaction}){
 async function identity(user,body){passenger(user);if(body.cliente_id!==undefined)check(String(body.cliente_id)===String(await ids.number('user',user.id)),403,'Identidade não corresponde à sessão');}
 async function save(user,input,{favorite=false,remember=false}={}){
  const body=object(input);await identity(user,body);
  const v={address:text(body.endereco??body.address,500),lat:coordinate(body.lat,90),lng:coordinate(body.lng,180),city:text(body.nome_cidade,100,true),state:text(body.nome_uf,60,true),district:text(body.bairro,120,true)};
  const label=favorite?text(body.apelido??body.label,100):'';
  const slot=favorite&&slots.has(label)?label:null;
  return transaction(pool,async db=>{
   await db.query('SELECT id FROM users WHERE id=$1 FOR UPDATE',[user.id]);
   if(favorite){const n=(await db.query('SELECT count(*)::int AS n FROM alce_saved_addresses WHERE user_id=$1 AND favorite AND address_key<>$2',[user.id,key(v)])).rows[0].n;check(n<100,422,'Limite de favoritos atingido');}
   // Presets have one destination per user. Replacing a preset keeps its old
   // address in history rather than silently deleting it.
   if(slot)await db.query('UPDATE alce_saved_addresses SET favorite=false,label=\'\',slot=NULL WHERE user_id=$1 AND slot=$2 AND address_key<>$3',[user.id,slot,key(v)]);
   const row=(await db.query(`INSERT INTO alce_saved_addresses(user_id,address_key,address,lat,lng,city,state,district,label,slot,favorite,searched_at)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,CASE WHEN $12 THEN clock_timestamp() END)
    ON CONFLICT(user_id,address_key) DO UPDATE SET address=excluded.address,city=excluded.city,state=excluded.state,district=excluded.district,
    favorite=alce_saved_addresses.favorite OR excluded.favorite,
    label=CASE WHEN excluded.favorite THEN excluded.label ELSE alce_saved_addresses.label END,
    slot=CASE WHEN excluded.favorite THEN excluded.slot ELSE alce_saved_addresses.slot END,
    searched_at=CASE WHEN $12 THEN clock_timestamp() ELSE alce_saved_addresses.searched_at END RETURNING id`,[user.id,key(v),v.address,v.lat,v.lng,v.city,v.state,v.district,label,slot,favorite,remember])).rows[0];
   await db.query(`DELETE FROM alce_saved_addresses WHERE user_id=$1 AND NOT favorite AND id IN
    (SELECT id FROM alce_saved_addresses WHERE user_id=$1 AND NOT favorite ORDER BY searched_at DESC NULLS LAST,id DESC OFFSET 30)`,[user.id]);
   return {id:row.id};
  });
 }
 async function list(user,history=false){
  passenger(user);const uid=await ids.number('user',user.id);
  const rows=(await pool.query(`SELECT * FROM alce_saved_addresses WHERE user_id=$1 AND ${history?'searched_at IS NOT NULL':'favorite'} ORDER BY ${history?'searched_at DESC,id DESC LIMIT 3':"CASE slot WHEN 'Casa' THEN 0 WHEN 'Trabalho' THEN 1 WHEN 'Escola' THEN 2 ELSE 3 END,label,id LIMIT 100"}`,[user.id])).rows;
  return rows.map(r=>({id:r.id,cliente_id:uid,endereco:r.address,apelido:r.label,lat:r.lat,lng:r.lng,bairro:r.district,complemento:'',nome_cidade:r.city,nome_uf:r.state,cidade:null}));
 }
 return {
  async initialize(){await pool.query(`CREATE TABLE IF NOT EXISTS alce_saved_addresses(
   id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,user_id uuid NOT NULL REFERENCES users(id),address_key text NOT NULL,
   address text NOT NULL,lat double precision NOT NULL CHECK(lat BETWEEN -90 AND 90),lng double precision NOT NULL CHECK(lng BETWEEN -180 AND 180),
   city text NOT NULL DEFAULT '',state text NOT NULL DEFAULT '',district text NOT NULL DEFAULT '',label text NOT NULL DEFAULT '',
   slot text CHECK(slot IN ('Casa','Trabalho','Escola')),favorite boolean NOT NULL DEFAULT false,searched_at timestamptz,
   UNIQUE(user_id,address_key),UNIQUE(user_id,slot));
   CREATE INDEX IF NOT EXISTS alce_saved_addresses_recent ON alce_saved_addresses(user_id,searched_at DESC);`);},
  save,list,
  async handle({path,body,user,method}){
   await identity(user,body);
   if(['/endereco/lista','/alce/addresses/favorites'].includes(path))return list(user);
   if(path==='/alce/addresses/history')return list(user,true);
   check(method==='POST',405,'Alteração exige POST');
   if(['/endereco/index','/alce/addresses/save'].includes(path))return save(user,object(body.endereco??body),{favorite:true});
   if(path==='/alce/addresses/remember')return save(user,object(body.endereco??body),{remember:true});
   if(['/endereco/exclusao','/alce/addresses/delete'].includes(path)){
    check(/^[1-9]\d{0,9}$/.test(String(body.id))&&Number(body.id)<=2147483647,400,'Identificador inválido');
    const r=await pool.query("UPDATE alce_saved_addresses SET favorite=false,label='',slot=NULL WHERE user_id=$1 AND id=$2 AND favorite RETURNING id",[user.id,body.id]);
    check(r.rowCount,404,'Endereço não encontrado');return {};
   }
   throw fail(404,'Operação de endereço indisponível');
  }
 };
}
